---
layout: page
title: About me
---

Hi, I'm Cristian Molina and I'm studying web development on IES Conselleria in Valencia. Also I'm starting a project with a friend called <a href="https://nulltilus.com" target="_blank">Nulltilus</a>.

You can find me on twitter [@legomolina](http://twitter.com/legomolina), see my [GitHub](http://github.com/legomolina) or send me an email to [legomolina@gmail.com](mailto:legomolina@gmail.com).
