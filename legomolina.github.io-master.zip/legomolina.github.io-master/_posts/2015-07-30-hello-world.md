---
layout: post
title: Hello world
date: 2015-07-30 23:26:00
disqus: y
---

Hola a todos y bienvenidos a mi nueva web personal donde iré colgando mis proyectos, algunos tutoriales que encuentre interesantes y tonterías varias que se me ocurran.

Esta web está enfocada principalmente al desarrollo web en todas sus formas: maquetación, programación desde el lado del cliente y desde el lado del servidor. Intentaré actualizarla a menudo pero no prometo nada ya que tengo otros quehaceres a parte de esto. Espero que os sirva de ayuda a todos y no os corteis a la hora de usar mis cosillas en vuestros sitios.

---

Por último agradecer a <a href="https://github.com/grenderg" target="_blank">Daniel Morales</a> su tarde intentando configurar la web para que todo funcione perfectamente :D.
